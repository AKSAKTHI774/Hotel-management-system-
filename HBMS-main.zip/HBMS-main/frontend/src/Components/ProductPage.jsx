import React from 'react'

const ProductPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default ProductPage
