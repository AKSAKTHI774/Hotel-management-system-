import React from 'react'

const SearchPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default SearchPage
