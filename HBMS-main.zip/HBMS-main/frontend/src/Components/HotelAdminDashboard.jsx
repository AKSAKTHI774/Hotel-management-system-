import React from 'react'

const AdminDashboard = () => {
  return (
    <div>
      
    </div>
  )
}

export default AdminDashboard
